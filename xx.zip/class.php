<?php

class gamer {
	function __construct() {

	}
	function password()
	{
		$pass = str_replace(" ", "",$this->nama().rand(1, 100));
		return $pass;
	}
	function negara() {
		$data = file_get_contents("negara.txt");
		$pisah = explode("\n", $data);
		return trim($pisah[array_rand($pisah)]);
	}
	function kota() {
		$data = file_get_contents("kota.txt");
		$pisah = explode("\n", $data);
		return trim($pisah[array_rand($pisah)]);
	}
	function nama()
	{
		$data = file_get_contents("nama.txt");
		$pisah = explode("\n", $data);
		$nama = "";
		$berapa = rand(1, 5);
		for ($i=0; $i < $berapa; $i++) { 
			$nama .= trim($pisah[array_rand($pisah)])." ";
		}
		return trim($nama);

	}
	function rc($panjang) {
		$data = array_merge(range("a", "z"), range("A", "Z"));
		if (isset($i)) {
			$data = array_merge(range("a", "z"), range("A", "Z"), range(0, 9));
		}
		$a = "";
		for ($i = 0; $i < $panjang; $i++) {
			$a .= $data[array_rand($data)];
		}
		return $a;

	}
	function ip() {
		return $randIP = "" . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255);
	}
	function login($email, $pass) {
		$data = md5($email . $pass);
		$a = "";
		for ($i = 0; $i < 16; $i++) {
			$a .= $data[$i];
		}
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, 'https://mgamer.back4app.io/functions/email_login_v1');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"name\":\"\",\"email\":\"$email\",\"ipdata\":\"\",\"device\":\"" . $a . "\",\"password\":\"$pass\",\"type\":\"login\"}");

		$headers = array();
		$headers[] = 'X-Parse-Application-Id: ' . "pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV";
		$headers[] = 'X-Parse-App-Build-Version: 47';
		$headers[] = 'X-Parse-App-Display-Version: 1.4.7';
		$headers[] = 'X-Parse-Os-Version: 5.1.1';
		$headers[] = 'User-Agent: Parse Android SDK API Level 22';
		$headers[] = 'X-Parse-Installation-Id: ' . $this->rc(8, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(12, 1) . '';
		$headers[] = 'X-Parse-Client-Key: ' . "H6pxBYl8gQ4JGAsBn6ouMeWtEqhqzE13YPdNrvnd";
		$headers[] = 'Content-Type: application/json';
//$headers[] = 'Content-Length: 111';
		$headers[] = 'Host: mgamer.back4app.io';
		$headers[] = 'Connection: close';
//$headers[] = 'Accept-Encoding: gzip, deflate';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		} else {
			$json = json_decode($result, 1);
			if (!isset($json['result'][1])) {
				echo $result;
				die("Gook !! Kon Iku Kok Piye Sek\n");
			} else {
				echo "Berhasil Login\n";
				echo "Email : $email\n";
			}
			$this->token = $token = $json['result'][1];
			//file_put_contents($email, $token);

		}
		curl_close($ch);
	}
	function add_reff($kode) {

		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, 'https://mgamer.back4app.io/functions/add_friend');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"name\":\"$kode\"}");

		$headers = array();
		$headers[] = 'X-Parse-Session-Token: ' . $this->token;
		$headers[] = 'X-Parse-Application-Id: pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV';
		$headers[] = 'X-Parse-App-Build-Version: 47';
		$headers[] = 'X-Parse-App-Display-Version: 1.4.7';
		$headers[] = 'X-Parse-Os-Version: 5.1.1';
		$headers[] = 'User-Agent: Parse Android SDK API Level 22';
		$headers[] = 'X-Parse-Installation-Id: ' . $this->rc(8, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(12, 1) . '';
		$headers[] = 'X-Parse-Client-Key: H6pxBYl8gQ4JGAsBn6ouMeWtEqhqzE13YPdNrvnd';
		$headers[] = 'Content-Type: application/json';
//$headers[] = 'Content-Length: 17';
		$headers[] = 'Host: mgamer.back4app.io';
		$headers[] = 'Connection: close';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		} else {

			echo $result;
			if (!preg_match("/taken/", $result) && !preg_match("/Internal/", $result)) {
				echo "Berhasil Masukkan Kode Reff\n";
			} else {
				//echo $result;
				echo "Sudah Masukkan Kode Woy \n";
			}
		}
		curl_close($ch);
	}
	function video() {
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, 'https://mgamer.back4app.io/functions/add_coin_video');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "{}");

		$headers = array();
		$headers[] = 'X-Parse-Session-Token: ' . $this->token;
		$headers[] = 'X-Parse-Application-Id: pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV';
		$headers[] = 'X-Parse-App-Build-Version: 47';
		$headers[] = 'X-Parse-App-Display-Version: 1.4.7';
		$headers[] = 'X-Parse-Os-Version: 5.1.1';
		$headers[] = 'User-Agent: Parse Android SDK API Level 22';
		$headers[] = 'X-Parse-Installation-Id: ' . $this->rc(8, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(12, 1) . '';
		$headers[] = 'X-Parse-Client-Key: H6pxBYl8gQ4JGAsBn6ouMeWtEqhqzE13YPdNrvnd';
		$headers[] = 'Content-Type: application/json';
//$headers[] = 'Content-Length: 2';
		$headers[] = 'Host: mgamer.back4app.io';
		$headers[] = 'Connection: close';
//$headers[] = 'Accept-Encoding: gzip, deflate';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		} else {
			if (preg_match('/{"result":"success"}/', $result)) {
				echo "Video Telah Habis\n";
				return 1;
			} else {
				//	echo $result;
				echo "Berhasil Liat Video\n";
			}
		}
		curl_close($ch);
	}
	function nuyul($email, $pass, $kode) {
		echo $this->login($email, $pass);
		while (1) {
			if ($this->video() == 1) {
				break;
			}

		}
		$this->add_reff($kode);
	}
	function daftar($email, $pass = "ibuku123") {
		$data = md5($email);
		$a = "";
		for ($i = 0; $i < 16; $i++) {
			$a .= $data[$i];
		}
		$ch = curl_init();
		//curl_setopt($ch, CURLOPT_VERBOSE, 1);
		//echo json_encode($datax);
 
 

		curl_setopt($ch, CURLOPT_URL, 'https://mgamer.back4app.io/functions/email_login_v1');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"name\":\"".$this->nama()."\",\"email\":\"$email\",\"ipdata\":\"{\\\"city\\\":\\\"".$this->kota()."\\\",\\\"country\\\":\\\"Indonesia\\\",\\\"proxy\\\":false,\\\"query\\\":\\\"".$this->ip()."\\\",\\\"regionName\\\":\\\"East Java\\\",\\\"status\\\":\\\"success\\\"}\",\"device\":\"$a\",\"password\":\"ibukuxaaaa\",\"type\":\"new\"}");

		$headers = array();
		$headers[] = 'X-Parse-Application-Id: pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV';
		$headers[] = 'X-Parse-App-Build-Version: 47';
		$headers[] = 'X-Parse-App-Display-Version: 1.4.7';
		$headers[] = 'X-Parse-Os-Version: 5.1.1';
		$headers[] = 'User-Agent: Parse Android SDK API Level 22';
		$headers[] = 'X-Parse-Installation-Id: ' . $this->rc(8, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(4, 1) . '-' . $this->rc(12, 1) . '';
		$headers[] = 'X-Parse-Client-Key: H6pxBYl8gQ4JGAsBn6ouMeWtEqhqzE13YPdNrvnd';
		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Host: mgamer.back4app.io';
		//$headers[] = 'Connection: close';
//$headers[] = 'Accept-Encoding: gzip, deflate';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		} else {
			echo $result;
		//	echo json_encode($datax);
		}
		curl_close($ch);
	}
	function email()
		{
			$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://api.internal.temp-mail.io/api/v2/email/new');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"min_name_length\":10,\"max_name_length\":10}");
	//curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

	$headers = array();
	$headers[] = 'Authority: api.internal.temp-mail.io';
	$headers[] = 'Accept: application/json, text/plain, */*';
	$headers[] = 'Dnt: 1';
	$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36';
	$headers[] = 'Content-Type: application/json;charset=UTF-8';
	$headers[] = 'Origin: https://temp-mail.io';
	$headers[] = 'Sec-Fetch-Site: same-site';
	$headers[] = 'Sec-Fetch-Mode: cors';
	$headers[] = 'Referer: https://temp-mail.io/en';
	//$headers[] = 'Accept-Encoding: gzip, deflate, br';
	$headers[] = 'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7';
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	$result = curl_exec($ch);
	if (curl_errno($ch)) {
	    echo 'Error:' . curl_error($ch);
	}else
	{
		$data = json_decode($result, 1);
		return $data['email'];
	}
	curl_close($ch);
	}
	function cek_mail($mail)
	{
		
		while (1) {

				$data = file_get_contents("https://api.internal.temp-mail.io/api/v2/email/$mail/messages");
		$data =json_decode($data,1);
		$pesan = $data[0]["body_text"];
		preg_match_all("/https:\/\/mgamer.back4app.io\/apps\/pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV\/verify_email\?token=(.*)&username=(.*)/", $pesan, $hasil);
			if (isset($hasil[0][0])) {
				echo "Email Ketemu \n";
				$link = $hasil[0][0];
				break;
			}
			
		}
		
		echo file_get_contents("$link");
		echo "Berhasil Verifikasi Email\n";
	}
}


?>

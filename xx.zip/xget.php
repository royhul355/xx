<?php

echo file_get_contents($argv[1]);

?>
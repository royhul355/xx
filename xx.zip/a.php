<?php
for ($i=0; $i < 2; $i++) { 
	# code...

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://mgamer.back4app.io/functions/email_login_v1');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"name\":\"Xcoere aa $i\",\"email\":\"tambangadja+".rand(1, 10).$i."golre@gmail.com\",\"ipdata\":\"{\\\"city\\\":\\\"La\\\",\\\"country\\\":\\\"Indonesia\\\",\\\"proxy\\\":false,\\\"query\\\":\\\"114.11.77.$i\\\",\\\"regionName\\\":\\\"East Java\\\",\\\"status\\\":\\\"success\\\"}\",\"device\":\"102fxbf3".$i."1f1d56x\",\"password\":\"ibukuxa".$i."aaa\",\"type\":\"new\"}");

$headers = array();
$headers[] = 'X-Parse-Application-Id: pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV';
$headers[] = 'X-Parse-App-Build-Version: 47';
$headers[] = 'X-Parse-App-Display-Version: 1.4.7';
$headers[] = 'X-Parse-Os-Version: 5.1.1';
$headers[] = 'User-Agent: Parse Android SDK API Level 22';
$headers[] = 'X-Parse-Installation-Id: e321c8a8-1db7-4af9-817b-64a8c1cc08f';
$headers[] = 'X-Parse-Client-Key: H6pxBYl8gQ4JGAsBn6ouMeWtEqhqzE13YPdNrvnd';
$headers[] = 'Content-Type: application/json';
//$headers[] = 'Content-Length: 303';
$headers[] = 'Host: mgamer.back4app.io';
$headers[] = 'Connection: close';
//$headers[] = 'Accept-Encoding: gzip, deflate';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}else
{
	echo $result;
}
curl_close($ch);
}

?>
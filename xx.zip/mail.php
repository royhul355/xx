<?php
$data = file_get_contents("mail.txt");
$arr1 = explode("\n", $data);
$data = file_get_contents("mail2.txt");
$arr2 = explode("\n", $data);
$data = file_get_contents("mail3.txt");
$arr3 = explode("\n", $data);
$data = file_get_contents("mail4");
$arr4 = explode("\n", $data);
$data = file_get_contents("mail5");
$arr5 = explode("\n", $data);
$data = file_get_contents("mail6");
$arr6 = explode("\n", $data);
$semua = array_merge($arr2,$arr3,$arr4,$arr5,$arr6);
$x = array();
//echo count($semua);
//die();
foreach ($semua as $key) {
	$nomor = array_rand($semua);
	$mail = $semua[$nomor];
	$x[] = $mail;
	unset($semua[$nomor]);
}
unlink("x.bat");
$xs = 0;
foreach ($x as $hasil) {
	$xs++;
	fwrite(fopen("x.bat", "a"), "start php b.php $hasil\n");
	if ($xs%20==0) {
	fwrite(fopen("x.bat", "a"), "exit\n");
		shell_exec("start x.bat");
		unlink("x.bat");
	    //sleep(1);
	}
	
	}
	
die();
for ($i=0; $i < 1000; $i++) { 
	$mail = $semua[array_rand($semua)];
	$pisah = explode("@", $mail);
	$mailx = $pisah[0]."+".rand("1", 1000)."@".$pisah[1];
	echo $mailx."\n";
}


?>
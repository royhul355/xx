<?php

	$data = file_get_contents("x.eml");
	preg_match_all("/https:\/\/mgamer.back4app.io\/apps\/pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV\/verify_email\?token=(.*)&username=(.*)/", $data, $hasil);
	unlink("xxs.bat");
	$xs = 0;
	//print_r($hasil[0]);
	foreach ($hasil[0] as $hasil1) {
		$xs++;
		$link = trim($hasil1);
		fwrite(fopen("xxs.bat", "a"), "start php xget.php $link\n");
	if ($xs%20==0) {
	    fwrite(fopen("xxs.bat", "a"), "exit\n");
		shell_exec("start xxs.bat");
		unlink("xxs.bat");
	}
}
	echo "\n\n\n";
//echo file_get_contents("data/".$dir[1]);
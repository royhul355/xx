<?php
$randIP = "" . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255);
$data = file_get_contents("http://ip-api.com/json/$randIP");
$json = json_decode($data,1);
print_r($json);
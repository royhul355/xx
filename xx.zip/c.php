<?php
$x = 10;
if ($x%20==0) {
	echo "Berhasil";
}
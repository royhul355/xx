<?php
for ($i=0; $i < 1000; $i++) { 
require 'class.php';
	$aku = new gamer();
//$email = $aku->email();
$pass = $aku->password();
$email = "royhul33+$pass"."@gmail.com";
echo $email." | ".$pass."\n";
fwrite(fopen("list.txt", "a"), "$email|$pass\n");
$aku->daftar("royhul33+$pass"."@gmail.com",$pass);
}
$aku = new gamer();
//$email = $aku->email();
$pass = $aku->password();
$email = "royhul33+$pass"."@gmail.com";
$pass = $pass.rand(1, 100);
echo $email." | ".$pass."\n";
fwrite(fopen("list.txt", "a"), "$email|$pass\n");
$aku->daftar("royhul33+$pass"."@gmail.com",$pass);
//$aku->cek_mail($email);
//$aku->login($email,$pass);
//$aku->add_reff("7yj2bLASFH");
//echo ;


?>
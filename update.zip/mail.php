<?php
$data = file_get_contents("mail.txt");
$arr1 = explode("\n", $data);
$data = file_get_contents("mail2.txt");
$arr2 = explode("\n", $data);
$data = file_get_contents("mail3.txt");
$arr3 = explode("\n", $data);
$data = file_get_contents("mail4");
$arr4 = explode("\n", $data);
$data = file_get_contents("mail5");
$arr5 = explode("\n", $data);
$data = file_get_contents("mail6");
$arr6 = explode("\n", $data);
$semua = array_merge($arr2,$arr3,$arr4,$arr5,$arr6);
$x = array();
//echo count($semua);
//die();
foreach ($semua as $key) {
	$nomor = array_rand($semua);
	$mail = $semua[$nomor];
	$x[] = $mail;
	unset($semua[$nomor]);
}
foreach ($x as $hasil) {
	echo shell_exec("php b.php $hasil");
}
die();
for ($i=0; $i < 1000; $i++) { 
	$mail = $semua[array_rand($semua)];
	$pisah = explode("@", $mail);
	$mailx = $pisah[0]."+".rand("1", 1000)."@".$pisah[1];
	echo $mailx."\n";
}


?>
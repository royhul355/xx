<?php
echo $argv[1];
$str = '{"result":"success"}';
echo strlen($str);


die();
$str = '{"result":["success","r:b91e7c29cb275835b66fc4a7fdae34d5"]}';
$json = json_decode($str, 1);
print_r($json);
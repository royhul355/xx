<?php
$w_arr = file_get_contents("mail.txt");
    echo implode($w_arr,"yaam\n");
    //implode("w", array:pieces)


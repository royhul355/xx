<?php

echo strlen("8322164b1e307396");


die();
require 'class.php';
for ($i=0; $i < 1; $i++) { 
	$x = new gamer;
	$pass = $x->password();
	$email = "tambangadja+$pass"."@gmail.com";
	fwrite(fopen("list.txt", "a"), "$email|$pass\n");
	$x->daftar($email,$pass);
	echo $email." | ".$pass."\n";
}



?>
<?php
while (1) {
	$randIP = "" . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255);
$url = "http://pro.ip-api.com/json/$randIP?key=uKzY0Cq1OmBvV64&fields=country,status";
$data = file_get_contents($url);
$json = json_decode($data, 1);
if ($json['status'] == "success") {
	echo "IP : $randIP\nNegara: ".$json['country']."\n";
	break;
}	
}

?>
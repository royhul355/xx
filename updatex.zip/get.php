<?php
$dir = scandir("data", 2);
unset($dir[0]);
unset($dir[1]);
foreach ($dir as $data) {
	;
	$data = file_get_contents("data/" . $data);
	preg_match_all("/https:\/\/parseapi.back4app.com\/apps\/pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV\/verify_email\?token=(.*)&username=(.*)/", $data, $hasil);
	foreach ($hasil[0] as $hasil1) {
		$link = trim($hasil1);
		echo file_get_contents($link);
	}
	echo "\n\n\n";
}
//echo file_get_contents("data/".$dir[1]);
<?php

// Rc
function rc($panjang,$i =1) {
		$data = array_merge(range("a", "z"), range("A", "Z"));
		if (isset($i)) {
			$data = array_merge(range("a", "z"), range("A", "Z"), range(0, 9));
		}
		$a = "";
		for ($i = 0; $i < $panjang; $i++) {
			$a .= $data[array_rand($data)];
		}
		return $a;

	}

// Nama
//for ($i=1; $i < 256; $i++) { 
	

$data['nama'] = file_get_contents("nama.txt");
$pisah = explode("\n", $data['nama']);
$nama = trim($pisah[array_rand($pisah)]);
// Kota
$data['kota'] = file_get_contents("kota.txt");
$pisah = explode("\n", $data['kota']);
$kota = trim($pisah[array_rand($pisah)]);

// Negara
//$data['negara'] = file_get_contents("negara.txt");
//$pisah = explode("\n", $data['negara']);
$negara = trim($pisah[array_rand($pisah)]);

// Email 
$email = $argv['1'];
// Fullname
$fullname = "$nama $nama";

while (1) {
	$randIP = "" . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 
		255) . "." . mt_rand(0, 255);
$url = "http://pro.ip-api.com/json/$randIP?key=uKzY0Cq1OmBvV64&fields=country,status";
$data = file_get_contents($url);
$json = json_decode($data, 1);
if ($json['status'] == "success") {
	echo "IP : $randIP\nNegara: ".$json['country']."\n";
	break;
}	
}


$negara = $json['country'];
$ch = curl_init();
$pass = $nama.rand(1, 10000);


curl_setopt($ch, CURLOPT_URL, 'https://mgamer.back4app.io/functions/email_login_v1');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"name\":\"$fullname\",\"email\":\"$email\",\"ipdata\":\"{\\\"city\\\":\\\"$kota\\\",\\\"country\\\":\\\"$negara\\\",\\\"proxy\\\":false,\\\"query\\\":\\\"$randIP\\\",\\\"regionName\\\":\\\"$kota\\\",\\\"status\\\":\\\"success\\\"}\",\"device\":\"".rc(16,1)."\",\"password\":\"$pass\",\"type\":\"new\"}");

$headers = array();
$headers[] = 'X-Parse-Application-Id: pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV';
$headers[] = 'X-Parse-App-Build-Version: 47';
$headers[] = 'X-Parse-App-Display-Version: 1.4.7';
$headers[] = 'X-Parse-Os-Version: 5.1.1';
$headers[] = 'User-Agent: Parse Android SDK API Level 22';
$headers[] = 'X-Parse-Installation-Id: ' . rc(8, 1) . '-' . rc(4, 1) . '-' . rc(4, 1) . '-' . rc(4, 1) . '-' . rc(12, 1) . '';
$headers[] = 'X-Parse-Client-Key: H6pxBYl8gQ4JGAsBn6ouMeWtEqhqzE13YPdNrvnd';
$headers[] = 'Content-Type: application/json';
//$headers[] = 'Content-Length: 303';
$headers[] = 'Host: mgamer.back4app.io';
$headers[] = 'Connection: close';
//$headers[] = 'Accept-Encoding: gzip, deflate';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}else
{
	$json = json_decode($result,1);
	if ($json['result'][0] == "signup") {
		echo "=> Berhasil Daftar\nEmail : $email\n\n";
		fwrite(fopen("list.txt", "a"), "$email|$pass\n");
	}else
	{
		//print_r($json['result']);
		echo "=> Sudah Terdaftar\nEmail : $email\n\n";
	}
}
curl_close($ch);
//}
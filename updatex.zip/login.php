<?php

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://mgamer.back4app.io/functions/email_login_v1');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"name\":\"\",\"email\":\"royhul34@gmail.com\",\"ipdata\":\"\",\"device\":\"9a94aacd590071ee\",\"password\":\"ibuku354\",\"type\":\"login\"}");

$headers = array();
$headers[] = 'X-Parse-Application-Id: pFNMj1vsRi4Xe8bCrCRgaK50wSRHGlXR4lOpYxiV';
$headers[] = 'X-Parse-App-Build-Version: 13';
$headers[] = 'X-Parse-App-Display-Version: 1.1.3';
$headers[] = 'X-Parse-Os-Version: 5.1.1';
$headers[] = 'User-Agent: Parse Android SDK API Level 22';
$headers[] = 'X-Parse-Installation-Id: d4083ff5-9741-4691-8708-4c6fa55f224d';
$headers[] = 'X-Parse-Client-Key: H6pxBYl8gQ4JGAsBn6ouMeWtEqhqzE13YPdNrvnd';
$headers[] = 'Content-Type: application/json';
//$headers[] = 'Content-Length: 111';
$headers[] = 'Host: parseapi.back4app.com';
$headers[] = 'Connection: close';
//$headers[] = 'Accept-Encoding: gzip, deflate';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
	echo 'Error:' . curl_error($ch);
} else {
	$json = json_decode($result, 1);
	print_r($json);
}
curl_close($ch);

?>